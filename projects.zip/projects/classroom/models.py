from django.db import models
from django.contrib.auth.models import User


class Classroom(models.Model):
    """班级"""
    name = models.CharField(max_length=100, verbose_name='班级名称')
    invite_code = models.CharField(max_length=20, unique=True, verbose_name='邀请码')
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='classrooms', verbose_name='创建教师')
    description = models.TextField(blank=True, verbose_name='班级描述')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '班级'
        verbose_name_plural = '班级'
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    @classmethod
    def generate_code(cls):
        """生成唯一邀请码"""
        import random
        import string
        while True:
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            if not cls.objects.filter(invite_code=code).exists():
                return code


class ClassMember(models.Model):
    """班级成员"""
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='members')
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='class_memberships')
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '班级成员'
        verbose_name_plural = '班级成员'
        unique_together = ('classroom', 'student')
        ordering = ['-joined_at']

    def __str__(self):
        return f"{self.classroom.name} - {self.student.username}"
