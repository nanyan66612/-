from django.urls import path
from . import views

app_name = 'classroom'

urlpatterns = [
    # 教师端
    path('', views.classroom_list, name='classroom_list'),
    path('create/', views.classroom_create, name='classroom_create'),
    path('<int:classroom_id>/', views.classroom_detail, name='classroom_detail'),
    path('<int:classroom_id>/delete/', views.classroom_delete, name='classroom_delete'),
    path('member/<int:member_id>/remove/', views.classroom_member_remove, name='classroom_member_remove'),
    # 学生端
    path('join/', views.classroom_join, name='classroom_join'),
    path('<int:classroom_id>/leave/', views.classroom_leave, name='classroom_leave'),
]
