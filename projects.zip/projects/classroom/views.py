from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Classroom, ClassMember


def is_teacher(user):
    """检查是否为教师"""
    if not user.is_authenticated:
        return False
    try:
        return user.profile.role == 'teacher'
    except:
        return False


def is_student(user):
    """检查是否为学生"""
    if not user.is_authenticated:
        return False
    try:
        return user.profile.role == 'student'
    except:
        return False


def teacher_required(view_func):
    """教师权限装饰器"""
    def wrapper(request, *args, **kwargs):
        if not is_teacher(request.user):
            messages.error(request, "您没有教师权限")
            return redirect('practice:practice_list')
        return view_func(request, *args, **kwargs)
    return wrapper


def student_required(view_func):
    """学生权限装饰器"""
    def wrapper(request, *args, **kwargs):
        if not is_student(request.user):
            messages.error(request, "请使用学生账号登录")
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@teacher_required
def classroom_list(request):
    """班级列表"""
    classrooms = Classroom.objects.filter(teacher=request.user)
    return render(request, 'classroom/classroom_list.html', {'classrooms': classrooms})


@login_required
@teacher_required
def classroom_create(request):
    """创建班级"""
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        code = Classroom.generate_code()
        
        classroom = Classroom.objects.create(
            name=name,
            invite_code=code,
            teacher=request.user,
            description=description
        )
        messages.success(request, f"班级创建成功！邀请码：{code}")
        return redirect('classroom:classroom_list')
    
    return render(request, 'classroom/classroom_form.html', {'action': '创建'})


@login_required
@teacher_required
def classroom_detail(request, classroom_id):
    """班级详情"""
    classroom = get_object_or_404(Classroom, id=classroom_id, teacher=request.user)
    members = ClassMember.objects.filter(classroom=classroom).select_related('student')
    return render(request, 'classroom/classroom_detail.html', {
        'classroom': classroom,
        'members': members
    })


@login_required
@teacher_required
def classroom_delete(request, classroom_id):
    """删除班级"""
    classroom = get_object_or_404(Classroom, id=classroom_id, teacher=request.user)
    classroom.delete()
    messages.success(request, "班级已删除")
    return redirect('classroom:classroom_list')


@login_required
@teacher_required
def classroom_member_remove(request, member_id):
    """移除班级成员"""
    member = get_object_or_404(ClassMember, id=member_id)
    if member.classroom.teacher == request.user:
        member.delete()
        messages.success(request, "已移除该学生")
    return redirect('classroom:classroom_detail', member.classroom.id)


@login_required
@student_required
def classroom_join(request):
    """学生加入班级"""
    if request.method == 'POST':
        code = request.POST.get('invite_code', '').strip().upper()
        if not code:
            messages.error(request, "请输入邀请码")
        else:
            try:
                classroom = Classroom.objects.get(invite_code=code)
                member, created = ClassMember.objects.get_or_create(
                    classroom=classroom,
                    student=request.user
                )
                if created:
                    messages.success(request, f"成功加入班级：{classroom.name}")
                else:
                    messages.info(request, "您已在该班级中")
            except Classroom.DoesNotExist:
                messages.error(request, "邀请码不存在")
        
        return redirect('classroom:classroom_join')
    
    # 获取学生已加入的班级
    memberships = ClassMember.objects.filter(student=request.user).select_related('classroom', 'classroom__teacher')
    return render(request, 'classroom/classroom_join.html', {'memberships': memberships})


@login_required
@student_required
def classroom_leave(request, classroom_id):
    """学生离开班级"""
    member = get_object_or_404(ClassMember, classroom_id=classroom_id, student=request.user)
    member.delete()
    messages.success(request, "已退出班级")
    return redirect('classroom:classroom_join')
