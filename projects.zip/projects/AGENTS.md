## 项目概述
C语言在线练习系统 - 基于Python/Django开发的毕业设计项目，实现随时刷题、代码校验、自动批改、错题管理等功能。

## 技术栈
- **框架**: Django 6.0
- **语言**: Python 3.12
- **数据库**: SQLite3
- **前端**: HTML5 + Bootstrap 5 + CodeMirror
- **图表**: Chart.js

## 目录结构
```
/workspace/projects/
├── c_practice_system/     # Django 项目配置
│   ├── settings.py       # 项目设置
│   └── urls.py           # 主路由
├── users/                # 用户管理模块
│   ├── models.py         # UserProfile, TeacherCode
│   └── views.py          # 登录/注册/登出
├── questions/            # 题目管理模块
│   ├── models.py         # Question, TestCase
│   └── views.py          # 题目CRUD
├── practice/             # 练习功能模块
│   ├── models.py         # Submit, WrongQuestion, PracticeStat
│   └── views.py          # 刷题/评测/统计
├── judge/                # 代码评测模块
│   └── judger.py         # C代码编译器
├── classroom/            # 班级管理模块
│   ├── models.py         # Classroom, ClassMember
│   └── views.py          # 班级CRUD、学生管理
├── templates/            # 前端模板
│   ├── base.html         # 基础模板
│   ├── login.html        # 登录页
│   ├── practice/         # 练习相关模板
│   ├── questions/        # 题目管理模板
│   ├── judge/            # 学情分析模板
│   └── classroom/        # 班级管理模板
└── db.sqlite3            # 数据库
```

## 关键入口
- **运行开发服务器**: `python manage.py runserver 0.0.0.0:8000`
- **数据库迁移**: `python manage.py migrate`
- **创建超级用户**: `python manage.py createsuperuser`
- **Django 管理后台**: `/admin/`

## 功能模块

### 学生端功能
| 功能 | 路由 | 说明 |
|------|------|------|
| 题目列表 | `/practice/list/` | 分类刷题、难度筛选 |
| 做题页面 | `/practice/<id>/` | CodeMirror编辑器 |
| 提交结果 | `/practice/submit/<id>/` | 评测结果反馈 |
| 错题本 | `/practice/wrong/` | 错题重做 |
| 我的统计 | `/practice/stats/` | 学习数据 |
| 提交记录 | `/practice/submissions/` | 历史提交 |

### 教师端功能
| 功能 | 路由 | 说明 |
|------|------|------|
| 班级管理 | `/classroom/` | 创建班级、查看成员、管理邀请码 |
| 提交审核 | `/judge/review/` | 审核学生的CE/RE/TLE提交 |
| 学情分析 | `/judge/dashboard/` | 总体统计（仅本班学生） |
| 题目管理 | `/questions/manage/` | CRUD |
| 提交记录 | `/judge/submissions/` | 查看所有提交 |
| 学生详情 | `/judge/student/<id>/` | 个人学习数据 |

### 学生端班级功能
| 功能 | 路由 | 说明 |
|------|------|------|
| 加入班级 | `/classroom/join/` | 输入邀请码加入班级 |
| 我的班级 | `/classroom/my/` | 查看已加入的班级 |

### 题目数据结构
```python
Question:
  - title: 题目名称
  - content: 题目描述
  - category: 知识点分类 (basic/condition/loop/array/function/pointer/string/structure/file)
  - difficulty: 难度 (easy/medium/hard)
  - test_input/test_output: 多组测试用例（用 --- 分隔）
```

### 提交记录数据结构
```python
Submit:
  - user: 提交用户
  - question: 题目
  - code: 提交代码
  - result: 结果 (AC/WA/CE/RE/TLE/RJ)
  - error_message: 错误信息
  - needs_review: 需要人工审核
  - reviewed_by: 审核教师
  - review_result: 人工审核结果 (AC/WA)
  - review_comment: 审核备注
```

### 班级数据结构
```python
Classroom:
  - name: 班级名称
  - description: 班级描述
  - teacher: 教师（外键）
  - invite_code: 邀请码（6位随机码）
  - created_at: 创建时间

ClassMember:
  - classroom: 班级（外键）
  - student: 学生（外键）
  - joined_at: 加入时间
```

## 用户偏好与长期约束
- 使用 Django ORM 管理数据库
- 数据库使用 SQLite3
- 前端使用 Bootstrap 5 + CodeMirror
- CodeMirror 编辑器主题：默认、Monokai

## 常见问题和预防
- 确保 SQLite3 数据库文件有读写权限
- 数据库迁移后需重启服务
- 教师注册需要有效的教师码
- 学情分析默认只显示本班学生，无班级时显示提示
- 班级邀请码为6位随机字符串，学生输入邀请码即可加入
- 登录相关 URL：`/login/` 是登录页面，`/accounts/login/` 会自动重定向到 `/login/`
- 管理员通过 `/admin-login/` 登录，禁止在学生/教师端登录管理员账号
- 所有 URL 反向解析需要使用命名空间格式（如 `{% url 'app:name' %}`）
- URL 命名空间：每个应用的 urls.py 需要设置 `app_name`，如 `app_name = 'judge'`
- 教师端访问学情分析时，模板中用户ID使用 `s.user_id` 而非 `s.user.id`（避免空值错误）

## URL 命名空间配置
| 应用 | 命名空间 | 说明 |
|------|----------|------|
| users | `users` | 登录、注册、登出 |
| practice | `practice` | 学生刷题 |
| questions | `questions` | 题目管理 |
| judge | `judge` | 评测、学情分析 |
| classroom | `classroom` | 班级管理 |

## 技术细节
- UserProfile.user 关联 Django User 模型
- ClassMember.student 关联 Django User 模型（学生用户）
- 学情分析页面中，使用 `user_id` 避免空值导致的错误
- 学生端访问教师页面会被重定向

## 初始数据
- 超级用户: admin / Admin@123
- 教师码: TEACHER2026
- 示例题目: 5道（Hello World、两数之和、判断奇偶数、求阶乘、数组最大值）
