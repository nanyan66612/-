from django.urls import path
from django.views.generic import RedirectView
from django.http import HttpResponseRedirect
from . import views

def redirect_to_login(request):
    """将 /accounts/login/ 重定向到 /login/"""
    return HttpResponseRedirect('/login/')

urlpatterns = [
    path('', views.index, name='index'),
    path('accounts/login/', redirect_to_login, name='account_login'),
    path('login/', views.user_login, name='login'),
    path('register/', views.register, name='register'),
    path('admin-login/', views.admin_login_view, name='admin_login'),
    path('student/', views.student_dashboard, name='student_dashboard'),
    path('teacher/', views.teacher_dashboard, name='teacher_dashboard'),
    path('logout/', views.user_logout, name='logout'),
]