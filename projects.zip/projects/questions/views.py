from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Question, TestCase
from .forms import QuestionForm, TestCaseForm
from users.models import UserProfile


def is_teacher(user):
    """检查是否为教师"""
    if not user.is_authenticated:
        return False
    try:
        return user.profile.role == 'teacher'
    except:
        return False


def teacher_required(view_func):
    """教师权限装饰器"""
    def wrapper(request, *args, **kwargs):
        if not is_teacher(request.user):
            messages.error(request, "您没有教师权限")
            return redirect('student_dashboard')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@teacher_required
def question_manage(request):
    """题目管理列表"""
    category = request.GET.get('category', '')
    difficulty = request.GET.get('difficulty', '')
    
    qs = Question.objects.all()
    if category:
        qs = qs.filter(category=category)
    if difficulty:
        qs = qs.filter(difficulty=difficulty)
    
    categories = Question.CATEGORY_CHOICES
    difficulties = Question.DIFFICULTY_CHOICES
    
    context = {
        'questions': qs,
        'categories': categories,
        'difficulties': difficulties,
        'filter_category': category,
        'filter_difficulty': difficulty,
    }
    return render(request, 'questions/question_manage.html', context)


@login_required
@teacher_required
def question_add(request):
    """添加题目"""
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            try:
                question.created_by = request.user.profile
            except:
                pass
            question.save()
            messages.success(request, "题目添加成功")
            return redirect('questions:question_manage')
    else:
        form = QuestionForm()
    return render(request, 'questions/question_form.html', {'form': form, 'action': '添加'})


@login_required
@teacher_required
def question_edit(request, pk):
    """编辑题目"""
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        form = QuestionForm(request.POST, instance=question)
        if form.is_valid():
            form.save()
            messages.success(request, "题目修改成功")
            return redirect('questions:question_manage')
    else:
        form = QuestionForm(instance=question)
    return render(request, 'questions/question_form.html', {'form': form, 'action': '编辑', 'question': question})


@login_required
@teacher_required
def question_delete(request, pk):
    """删除题目"""
    question = get_object_or_404(Question, pk=pk)
    question.delete()
    messages.success(request, "题目删除成功")
    return redirect('question_manage')


@login_required
@teacher_required
def question_detail(request, pk):
    """查看题目详情"""
    question = get_object_or_404(Question, pk=pk)
    test_cases = question.test_cases.all()
    
    # 计算统计数据
    total_submits = question.submits.count()
    ac_count = question.submits.filter(result='AC').count()
    ac_rate = round(ac_count / total_submits * 100, 1) if total_submits > 0 else 0
    
    return render(request, 'questions/question_detail.html', {
        'question': question,
        'test_cases': test_cases,
        'total_submits': total_submits,
        'ac_count': ac_count,
        'ac_rate': ac_rate
    })


@login_required
@teacher_required
def test_case_add(request, question_pk):
    """添加测试用例"""
    question = get_object_or_404(Question, pk=question_pk)
    if request.method == 'POST':
        form = TestCaseForm(request.POST)
        if form.is_valid():
            test_case = form.save(commit=False)
            test_case.question = question
            test_case.save()
            messages.success(request, "测试用例添加成功")
            return redirect('questions:question_detail', pk=question.pk)
    else:
        form = TestCaseForm()
    return render(request, 'questions/test_case_form.html', {
        'form': form, 
        'question': question,
        'action': '添加'
    })


@login_required
@teacher_required
def test_case_edit(request, pk):
    """编辑测试用例"""
    test_case = get_object_or_404(TestCase, pk=pk)
    if request.method == 'POST':
        form = TestCaseForm(request.POST, instance=test_case)
        if form.is_valid():
            form.save()
            messages.success(request, "测试用例修改成功")
            return redirect('question_detail', pk=test_case.question.pk)
    else:
        form = TestCaseForm(instance=test_case)
    return render(request, 'questions/test_case_form.html', {
        'form': form,
        'test_case': test_case,
        'question': test_case.question,
        'action': '编辑'
    })


@login_required
@teacher_required
def test_case_delete(request, pk):
    """删除测试用例"""
    test_case = get_object_or_404(TestCase, pk=pk)
    question_pk = test_case.question.pk
    test_case.delete()
    messages.success(request, "测试用例删除成功")
    return redirect('question_detail', pk=question_pk)
