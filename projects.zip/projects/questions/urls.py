from django.urls import path
from . import views

app_name = 'questions'

urlpatterns = [
    path('manage/', views.question_manage, name='question_manage'),
    path('add/', views.question_add, name='question_add'),
    path('<int:pk>/edit/', views.question_edit, name='question_edit'),
    path('<int:pk>/delete/', views.question_delete, name='question_delete'),
    path('<int:pk>/', views.question_detail, name='question_detail'),
    # 测试用例
    path('<int:question_pk>/test-case/add/', views.test_case_add, name='test_case_add'),
    path('test-case/<int:pk>/edit/', views.test_case_edit, name='test_case_edit'),
    path('test-case/<int:pk>/delete/', views.test_case_delete, name='test_case_delete'),
]
