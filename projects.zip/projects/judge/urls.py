from django.urls import path
from . import views

app_name = 'judge'

urlpatterns = [
    path('dashboard/', views.teacher_stats, name='teacher_stats'),
    path('submissions/', views.all_submissions, name='submission_list'),
    path('student/<int:user_id>/', views.student_detail, name='student_detail'),
    path('question/<int:question_id>/', views.question_stats, name='question_stats'),
    path('review/', views.review_list, name='review_list'),
    path('review/<int:submit_id>/', views.review_submit, name='review_submit'),
]
